rm -r -f /var/www/*
rm -r -f /etc/systemd/system/website.service
