systemctl stop website.service
systemctl disable website.service
